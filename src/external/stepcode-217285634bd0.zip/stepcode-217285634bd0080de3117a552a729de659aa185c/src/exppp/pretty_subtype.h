#ifndef PRETTY_SUBTYPE_H
#define PRETTY_SUBTYPE_H

#include <express/expr.h>

char * SUBTYPEto_string( Expression e );
void SUBTYPEout( Expression e );


#endif /* PRETTY_SUBTYPE_H */
