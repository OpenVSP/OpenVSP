/**

\page doc_serialization Serialization

\section doc_serialization_vars Serialization of global variables

\todo Refer to reflection.

\section doc_serialization_objects Serialization of objects

\todo Refer to reflection for serialization. Mention CreateUnitializedScriptObject for deserialization.

\section doc_serialization_contexts Serialization of contexts

\todo Give overview of the steps to serialize contexts.


\see \ref doc_adv_dynamic_build_hot, \ref doc_adv_reflection, \ref doc_addon_serializer

*/
