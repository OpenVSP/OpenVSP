/*
  Diese vorcompilierte Header-Include-Datei wurde am 11.06.2010 16:48:11 vom 
  RAD Studio-Experten f�r vorcompilierte Header mit den folgenden Einstellungen 
  erzeugt:

  Projekt: E:\Eigene Dateien\RAD Studio\Projekte\repository\3rdparty\AngelScript\svn\tests\test_feature\projects\BCBuilder\test_feature.cbproj
  AllowUnguarded = -1
  ExcludeProjectFiles = -1
  IncludePathsOn = -1
  IncludePaths = 
  ExcludePaths = 
  IncludeCount = 1
  ManageHeader = -1
  Excluded = ..\..\..\..\angelscript\include\angelscript.h
  Excluded = ..\..\..\..\add_on\scriptarray\scriptarray.h
  Excluded = ..\..\..\..\add_on\scriptany\scriptany.h
  Included = $(BDS)\include\stdarg.h
  Excluded = ..\..\..\..\add_on\scriptdictionary\scriptdictionary.h
  Excluded = ..\..\..\..\add_on\scriptfile\scriptfile.h
  Excluded = ..\..\..\..\add_on\autowrapper\aswrappedcall.h
  Excluded = ..\..\..\..\add_on\scriptbuilder\scriptbuilder.h
  Excluded = ..\..\..\..\add_on\scriptmath\scriptmath.h
  Excluded = ..\..\..\..\add_on\scriptmath3d\scriptmath3d.h
  Included = $(BDS)\include\stddef.h
  Included = $(BDS)\include\math.h
*/

#ifndef pch1_H
#define pch1_H
#include <tchar.h>
#include <memory.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
#include <stdarg.h>
#include <sstream>
#include <iostream>
#include <vector>
#include <stdlib.h>
#include <stddef.h>
#include <string>
#include <math.h>
#endif
