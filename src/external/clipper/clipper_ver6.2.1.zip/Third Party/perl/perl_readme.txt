
A Perl module written by Steffen M�ller < smueller@cpan.org > 
that wraps the Clipper library can be downloaded from:

https://metacpan.org/module/Math::Clipper 