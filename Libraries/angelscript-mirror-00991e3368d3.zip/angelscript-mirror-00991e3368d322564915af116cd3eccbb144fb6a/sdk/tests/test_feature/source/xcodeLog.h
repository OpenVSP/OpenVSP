//
//  xcodeLog.h
//
//  Created by Jordi Oliveras Rovira on 04/04/14.
//

#ifndef xcodeLog_h
#define xcodeLog_h

int printfXcode(const char * __restrict format, ...);

#endif
