echo "to start, type 'r' then press enter after lldb loads!"
lldb --arch x86_64 ./delabella-sdl2 100000 -- --arch arvm7
