#ifndef NX
#define NX 100
#endif
