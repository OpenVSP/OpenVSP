#ifndef LOCAL_H
#define LOCAL_H

int local();

#endif // LOCAL_H

