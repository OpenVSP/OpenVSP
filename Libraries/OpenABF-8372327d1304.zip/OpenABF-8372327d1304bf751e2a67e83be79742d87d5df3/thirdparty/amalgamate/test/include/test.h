#ifndef TEST_H
#define TEST_H

#undef NDEBUG
#include <assert.h>

#endif // TEST_H

