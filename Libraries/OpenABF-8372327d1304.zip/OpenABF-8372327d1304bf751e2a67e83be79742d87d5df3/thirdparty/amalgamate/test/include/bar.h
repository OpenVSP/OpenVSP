#ifndef BAR_H
#define BAR_H

#include "foo.h"
#include "pragma_once.h"

int bar();

#endif // BAR_H

