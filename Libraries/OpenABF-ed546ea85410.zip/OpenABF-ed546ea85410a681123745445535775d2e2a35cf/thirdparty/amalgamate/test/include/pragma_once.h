#pragma once

int pragma_once();
