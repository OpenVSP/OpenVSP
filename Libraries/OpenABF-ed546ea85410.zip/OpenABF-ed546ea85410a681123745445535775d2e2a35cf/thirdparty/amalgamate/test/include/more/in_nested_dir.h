#include <time.h>
#include "local.h"

int in_nested_dir = 0;
