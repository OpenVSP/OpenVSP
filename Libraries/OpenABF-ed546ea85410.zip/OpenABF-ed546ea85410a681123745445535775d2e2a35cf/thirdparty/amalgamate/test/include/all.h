#ifndef ALL_H
#define ALL_H

#include "foo.h"
#include "bar.h"
#include "test.h"
#include "pragma_once.h"
#include "more/in_nested_dir.h"

#endif // ALL_H

