#ifndef FOO_H
#define FOO_H

// #include "bar.h"
// #include <bar.h>
/* #include "bar.h" */
/* #include <bar.h> */

int foo();

#endif // FOO_H

