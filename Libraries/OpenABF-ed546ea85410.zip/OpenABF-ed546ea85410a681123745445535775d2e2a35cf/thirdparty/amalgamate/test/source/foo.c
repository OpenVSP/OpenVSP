
#include "foo.h"

int foo()
{
	return 1;
}

