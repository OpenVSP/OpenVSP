
#include "bar.h"

int bar()
{
	return 1 + foo();
}

