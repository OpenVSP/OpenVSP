Code-Eli
========

Collection of C++ libraries that provide a variety of functionalities. The only library dependencies 
are Eigen3 and CPPTest (only if you want to unit test). This uses CMake to build.
