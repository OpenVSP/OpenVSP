
# if oneshot is true, don't run exp2cxx if source files exist. if schema.cc exists, assume others do
if(NOT DEFINED API_VERSION OR "${API_VERSION}" STREQUAL "")
  set(API_VERSION 1)
endif()
if(NOT DEFINED METADATA_PROFILE OR "${METADATA_PROFILE}" STREQUAL "")
  set(METADATA_PROFILE full)
endif()

if(ONESHOT AND EXISTS "${SDIR}/schema.cc")
  message("WARNING: SC_GENERATE_CXX_ONESHOT is enabled. If generated code has been modified, it will NOT be rewritten!")
  message("This is ONLY for debugging STEPcode internals!")
else()
  set(_exp2cxx_mode_args)
  if(LATE_BOUND)
    list(APPEND _exp2cxx_mode_args --late-bound)
  endif()
  if(COMPAT_NAMES)
    list(APPEND _exp2cxx_mode_args --compat-names)
  endif()
  list(APPEND _exp2cxx_mode_args --metadata ${METADATA_PROFILE})
  execute_process(COMMAND ${CMAKE_COMMAND} -E env ${GENERATOR_ENVIRONMENT}
    ${EXE} -k ${CHUNK_SIZE} -V ${API_VERSION} ${_exp2cxx_mode_args} ${EXP}
    WORKING_DIRECTORY ${SDIR}
    RESULT_VARIABLE _res
    OUTPUT_FILE exp2cxx_stdout.txt
    ERROR_FILE exp2cxx_stderr.txt
   )
  if(NOT "${_res}" STREQUAL "0")
    message(FATAL_ERROR "${EXE} reported an error for ${EXP}.\nsee exp2cxx_stdout.txt and exp2cxx_stderr.txt in ${SDIR} for details.")
  endif(NOT "${_res}" STREQUAL "0")
  # TODO count number of lines in stdout/stderr and tell user?
endif()

# Local Variables:
# tab-width: 8
# mode: cmake
# indent-tabs-mode: t
# End:
# ex: shiftwidth=2 tabstop=8
